import matplotlib.pylab as plt
import numpy as np

# Theta1 = np.genfromtxt("golub_gauss_theta.csv", delimiter=",")
# Theta2 = np.genfromtxt("golub_quadrant_Theta.csv", delimiter=",")
# Theta3 = np.genfromtxt("golub_spearman_theta.csv", delimiter=",")

# plt.spy(Theta1)
# plt.show()
# plt.spy(Theta2)
# plt.show()
# plt.spy(Theta3)
# plt.show()

S1 = np.genfromtxt("golub_gauss_S.csv", delimiter=",")
S2 = np.genfromtxt("golub_quadrant_S.csv", delimiter=",")
S3 = np.genfromtxt("golub_spearman_S.csv", delimiter=",")

plt.spy(S1)
plt.show()
plt.spy(S2)
plt.show()
plt.spy(S3)
plt.show()
