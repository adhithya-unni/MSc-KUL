# Robust_Statistics

The code is split up into:
1. robust_stat.R -- necessary functions to compute precision matrices and divergences
2. simulations.R -- code to compute the simulations (1 main function with all parameters)
3. breast-cancer-wisconsin.R -- calculates npd spearman, npd quadrant and gauss for the
                                the dataset breast-cancer-wisconsin.data
4. golub_precision.R -- calculates npd spearman, npd quadrant and gauss for 
                        the dataset golub (gene expressions)
5. test.cpp -- code that speeds up matrix calculations by using cpp instead of R
6. spy.py -- code that generates spy plots for the results.

The results are split up into:
1. Breast cancer results:
    (a) breastW_gauss.csv
    (b) breastW_quadrant.csv
    (c) breastW_spearman.csv
2. Golub results:
    (a) golub_gauss_S.csv
    (b) golub_gauss_theta.csv
    (c) golub_quadrant_S.csv
    (d) golub_quadrant_Theta.csv
    (e) golub_spearman_S.csv
    (f) golub_spearman_theta.csv
    (g) theta_gauss_spy.png       -- spy plot of gauss prec. mat.
    (h) theta_quadrant_spy.png    -- spy plot of quadr prec. mat.
    (i) theta_spearman_spy.png    -- spy plot of spear prec. mat.
3. Simulation results:
    (a) sim_50_5_100_0.csv    -- simulation for n=50, p=5, M=100, contamination=0%
    (a) sim_50_5_100_1.csv    -- simulation for n=50, p=5, M=100, contamination=10%
    (a) sim_50_100_100_0.csv  -- simulation for n=50, p=100, M=100, contamination=0%
    (a) sim_50_100_100_1.csv    -- simulation for n=50, p=100, M=100, contamination=10%
