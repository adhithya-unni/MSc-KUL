####################################################
## This file computes three different estimates for the precision matrix of the
## partial golub dataset
####################################################

source("robust_stat.R")

# INSTALL THIS IF IT DOES NOT WORK
# if (!requireNamespace("BiocManager", quietly = TRUE))
#   install.packages("BiocManager")
# 
# BiocManager::install("golubEsets")

library(golubEsets) #contains golub, obviously

data("Golub_Merge") #gives a list

data<-t(Golub_Merge@assayData$exprs) #only interested in the data set
# We only want the 100 smallest (absolute norm) variables
data2=abs(data)
sommen = colSums(data2)
rm(data2)
sommen2 = sort(sommen) 
indices <- which(sommen <= sommen2[100]) #smallest 100 vectors
data<-data[,indices] #store smallest 100 vectors
rm(Golub_Merge) #remove the huge list
gc()

nrows=nrow(data)

# quadrant 3-step
threestep.quadrant <- quadrant.transformed(data, method="npd")
# write.table( threestep.quadrant,"golub_quadrant_S.csv" , sep=",",  row.names=FALSE, col.names=FALSE)
ths.quad.theta <- theta.sparse(threestep.quadrant, n=nrows)
# write.table( ths.quad.theta,"golub_quadrant_Theta.csv" , sep=",",  row.names=FALSE, col.names=FALSE)

# spearman 3-step
threestep.spearman <- spearman.transformed(data, method="npd")
# write.table(threestep.spearman, "golub_spearman_S.csv", sep=",",  row.names=FALSE, col.names=FALSE)
ths.sp.theta <- theta.sparse(threestep.spearman, n=nrows)
# write.table(ths.sp.theta, "golub_spearman_theta.csv", sep=",",  row.names=FALSE, col.names=FALSE)

# Gauss
twostep.gaussian <- Grank(data)
# write.table(twostep.gaussian, "golub_gauss_S.csv", sep=",",  row.names=FALSE, col.names=FALSE)
tws.gauss.theta <- theta.sparse(twostep.gaussian, n=nrows)
# write.table(tws.gauss.theta, "golub_gauss_theta.csv", sep=",",  row.names=FALSE, col.names=FALSE)
